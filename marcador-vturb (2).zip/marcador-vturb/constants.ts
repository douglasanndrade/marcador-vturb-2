
export const WEBHOOKS = {
  LOGIN: 'https://n8n-n8n.68tvlf.easypanel.host/webhook/6a04f643-60ba-4618-9815-6777a466a974',
  CONFIG: 'https://n8n-n8n.68tvlf.easypanel.host/webhook/588b7b85-ea63-48a9-af01-732ed41e4bee'
};

export const SESSION_KEY = 'v_turb_session';
